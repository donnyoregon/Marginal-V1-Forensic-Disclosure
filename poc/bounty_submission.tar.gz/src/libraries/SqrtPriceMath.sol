// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
library SqrtPriceMath {
    function getNextSqrtPrice(uint256 nextX96) internal pure returns (uint160) {
        // CRITICAL BUG: Explicit cast truncates silently without overflow check
        return uint160(nextX96);
    }
}
