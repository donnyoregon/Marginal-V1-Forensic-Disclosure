// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
contract MarginalV1Factory {
    mapping(uint256 => bool) public getLeverage;
    constructor() {
        getLeverage[250000] = true;  // 25%
        getLeverage[500000] = true;  // 50%
        getLeverage[1000000] = true; // 100%
    }
    function createPool(uint256 maintenance) external view {
        if (!getLeverage[maintenance]) revert("InvalidMaintenance()");
    }
}
